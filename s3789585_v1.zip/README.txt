﻿Name: LIU SHIH MIN G
Student ID: s3789585
Website URL: https://saturn.csit.rmit.edu.au/~s3789585/wp/a1/index.html
Cites:
Adhinugroho, N.F. (2020). Fight Covid-19 Freebies. Available at: https://www.figma.com/community/file/849809659468946971/Fight-Covid-19-Freebies [Accessed 17 Aug. 2021].
Adobe Inc. (2021). Free Logo Maker: Design Custom Logos | Adobe Spark. [online] Adobe.com. Available at: https://www.adobe.com/express/create/logo [Accessed 5 Aug. 2021].
Beyondblue.org.au. (2021). Supporting you through the Coronavirus pandemic - Beyond Blue. [online] Available at: https://coronavirus.beyondblue.org.au/ [Accessed 19 Aug. 2021].
Business Victoria. (2021a). Business recovery and resilience mentoring. [online] Available at: https://business.vic.gov.au/grants-and-programs/business-recovery-and-resilience-mentoring [Accessed 19 Aug. 2021].
Business Victoria. (2021b). Small Business COVID Hardship Fund. [online] Available at: https://business.vic.gov.au/grants-and-programs/small-business-covid-hardship-fund [Accessed 19 Aug. 2021].
Cerulean Advanced Fitness and WellnessTM. (2018). Knowing Your Numbers and Living a Healthy Lifestyle - Cerulean Advanced Fitness and WellnessTM. [online] Available at: https://www.livecerulean.com/knowing-your-numbers-and-living-a-healthy-lifestyle/ [Accessed 18 Aug. 2021].
Cheltenham Community Centre. (2021a). Yoga. [online] Available at: http://www.chelt.com.au/yoga.html [Accessed 18 Aug. 2021].
Cheltenham Community Centre. (2021b). Yoga. [online] Available at: http://www.chelt.com.au/yoga.html [Accessed 18 Aug. 2021].
Cincinnatichildrens.org. (2019). Healthy Habits | Coronavirus Resources for Families. [online] Available at: https://www.cincinnatichildrens.org/patients/coronavirus-information/family-resources/healthy-habits [Accessed 18 Aug. 2021].
Cse.hku.hk. (2021). Centre For Sports and Exercise. [online] Available at: https://www.cse.hku.hk/phyact.asp?pageid=154 [Accessed 18 Aug. 2021].
Cumulus Outdoors. (2021). Outdoor Adventure Activities and Learning Outcomes | School Trips. [online] Available at: https://www.cumulusoutdoors.com/schools/outdoor-adventure-activities-for-schools/ [Accessed 19 Aug. 2021].
Flowbase (2020). Flowbase | SaaS Landing Page. Available at: https://www.figma.com/community/file/877750883399287145/Flowbase-%7C-SaaS-Landing-Page [Accessed 19 Aug. 2021].
Focus Physical Therapy. (2020). 9 Ways Stretching Can Improve Your Health and Wellness - PT. [online] Available at: https://focusphysicaltherapyscv.com/9-ways-stretching-can-improve-your-health-and-wellness/ [Accessed 18 Aug. 2021].
freepikcompany (n.d.). Storyset. Available at: https://storyset.com/ [Accessed 17 Aug. 2021].
Gayathri Menon (2020). Covid-19: Yoga to the rescue in this lockdown. [online] Hindustan Times. Available at: https://www.hindustantimes.com/fitness/yoga-to-the-rescue-in-this-lockdown/story-J3uaUAjRxbBCDg0xVIgkIM.html [Accessed 18 Aug. 2021].
Green, J., Huberty, J., Puzia, M. and Stecher, C. (2021). The Effect of Meditation and Physical Activity on the Mental Health Impact of COVID-19–Related Stress and Attention to News Among Mobile App Users in the United States: Cross-sectional Survey. JMIR Mental Health, [online] 8(4), p.e28479. Available at: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8045775/ [Accessed 18 Aug. 2021].
Headtohealth.gov.au. (2021). COVID-19 Support | Head to Health. [online] Available at: https://www.headtohealth.gov.au/covid-19-support/covid-19-support [Accessed 19 Aug. 2021].
Icons8.com. (2021). Free Icons, Clipart Illustrations, Photos, and Music. [online] Available at: https://icons8.com/ [Accessed 18 Aug. 2021].
Kovalevich, M. (2020). Delivery App_UI Kit. Available at: https://www.figma.com/community/file/852455074698003039/Delivery-App_UI-Kit [Accessed 17 Aug. 2021].
Lappset. (2021). 10 reasons why outdoor training is better than a gym workout. [online] Available at: https://www.lappset.com/News-and-updates/Blogs-and-articles/10-reasons-why-outdoor-training-is-better-than-a-gym-workout [Accessed 19 Aug. 2021].
Leoni Jesner, ACE-CPT (2020). Here’s How Long You Should Be Holding a Stretch. [online] Byrdie. Available at: https://www.byrdie.com/how-long-should-you-hold-a-stretch-5089996 [Accessed 18 Aug. 2021].
marilisaraccoglobal (2017). This is what your breakfast, lunch and dinner calories actually look like. [online] Global News. Available at: https://globalnews.ca/news/3615212/this-is-what-your-breakfast-lunch-and-dinner-calories-actually-look-like/ [Accessed 10 Aug. 2021].
MasterClass. (2020). Jon Kabat-Zinn Teaches Mindfulness and Meditation. [online] Available at: https://www.masterclass.com/classes/jon-kabat-zinn-teaches-mindfulness-and-meditation?campaignid=14127357985&adgroupid=124287790446&adid=537133287296&gclid=CjwKCAjw3_KIBhA2EiwAaAAliv5S-E_yPkpBxOK3ol4v2oQxKRzQslxCNqjC2x2q-8UYmVHVUGA-ORoCeXIQAvD_BwE [Accessed 18 Aug. 2021].
NDTV Food (2016). 5 Easy Stretching Exercises to Improve Your Flexibility. [online] NDTV Food. Available at: https://food.ndtv.com/health/5-easy-stretching-exercises-to-improve-your-flexibility-1635515 [Accessed 18 Aug. 2021].
NewsLifeMedia (2021). Recipes, recipes and recipes - Taste. [online] www.taste.com.au. Available at: https://www.taste.com.au/plan/healthy-meal-planner [Accessed 9 Aug. 2021].
Omarov, U. (2021). Login Signup Page. Available at: https://www.figma.com/community/file/986319835192854247/Login-Signup-Page [Accessed 17 Aug. 2021].
Pritikin Weight Loss Resort. (2013). Flexibility 101 | Stretching For Beginners | Pritikin Fitness Camp. [online] Available at: https://www.pritikin.com/your-health/healthy-living/getting-fit/303-stretching-101.html [Accessed 18 Aug. 2021].
Qld.gov.au. (2020). Six healthy habits you should hold on to post-pandemic. [online] Available at: https://www.health.qld.gov.au/news-events/news/healthy-habits-to-hold-on-to-after-pandemic-queensland-health-covid-coronavirus [Accessed 18 Aug. 2021].
Queensu.ca. (2020). Meditation | Faith and Spiritual Life. [online] Available at: https://www.queensu.ca/faith-and-spiritual-life/resources/meditation [Accessed 18 Aug. 2021].
REARDIN, R. (2020). 4 Expert Tips You Need to Know to Stretch Properly. [online] Best Health Magazine Canada. Available at: https://www.besthealthmag.ca/article/how-to-stretch-properly/ [Accessed 18 Aug. 2021].
Technology Networks (2020). Yoga Shown to Improve Anxiety, New Study Confirms. [online] Neuroscience from Technology Networks. Available at: https://www.technologynetworks.com/neuroscience/news/yoga-shown-to-improve-anxiety-new-study-confirms-338568 [Accessed 18 Aug. 2021].
The Santa Barbara Independent. (2020a). Zoom Livestream: Mindfulness and Compassion Meditation: COVID 19. [online] Available at: https://www.independent.com/events/mindfulness-and-compassion-meditation-covid-19-11/ [Accessed 18 Aug. 2021].
The Santa Barbara Independent. (2020b). Zoom Livestream: Mindfulness and Compassion Meditation: COVID 19. [online] Available at: https://www.independent.com/events/mindfulness-and-compassion-meditation-covid-19-11/ [Accessed 18 Aug. 2021].
Tolbert, T. (2021). Food Order App. Available at: https://www.figma.com/community/file/958575856767432241/Food-Order-App [Accessed 17 Aug. 2021].
Utah.com. (2020). Grand Canyon National Park. [online] Available at: https://utah.com/grand-canyon-national-park [Accessed 19 Aug. 2021].